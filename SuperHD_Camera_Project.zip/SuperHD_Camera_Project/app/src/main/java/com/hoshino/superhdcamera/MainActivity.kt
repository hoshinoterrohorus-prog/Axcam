package com.hoshino.superhdcamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Color
import android.net.Uri
import java.io.OutputStream
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private var imageCapture: ImageCapture? = null
    private var camera: Camera? = null
    private var backCamera = true
    private var flashOn = false
    private var hdrLook = false
    private var zoom = 1f
    private var aiHdEnabled = false
    private lateinit var flashButton: Button
    private lateinit var hdrButton: Button
    private lateinit var zoomLabel: TextView

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else Toast.makeText(this, "Izin kamera diperlukan untuk menggunakan aplikasi.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF05070B.toInt())
        }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(previewView, LinearLayout.LayoutParams(-1, 0, 1f))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(16, 12, 16, 18)
            setBackgroundColor(0xFF10141C.toInt())
        }
        val title = TextView(this).apply {
            text = "SUPERHD  •  CAMERA"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        controls.addView(title, LinearLayout.LayoutParams(-1, -2))
        zoomLabel = TextView(this).apply {
            text = "Zoom 1.0×"
            textSize = 12f
            setTextColor(0xFFB9C4D4.toInt())
            gravity = Gravity.CENTER
        }
        controls.addView(zoomLabel, LinearLayout.LayoutParams(-1, -2))
        val zoomBar = SeekBar(this).apply { max = 300; progress = 0 }
        controls.addView(zoomBar, LinearLayout.LayoutParams(-1, -2))
        zoomBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                zoom = 1f + progress / 100f
                zoomLabel.text = "Zoom %.1f×".format(Locale.US, zoom)
                camera?.cameraInfo?.zoomState?.value?.let {
                    val maxZoom = camera?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 1f
                    camera?.cameraControl?.setZoomRatio(zoom.coerceAtMost(maxZoom))
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        fun button(label: String, action: () -> Unit): Button = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        flashButton = button("Flash OFF") {
            flashOn = !flashOn
            flashButton.text = if (flashOn) "Flash ON" else "Flash OFF"
            imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        }
        hdrButton = button("HDR LOOK OFF") {
            hdrLook = !hdrLook
            hdrButton.text = if (hdrLook) "HDR LOOK ON" else "HDR LOOK OFF"
            Toast.makeText(this, if (hdrLook) "Pratinjau HDR-look aktif. Ini bukan computational HDR GCam." else "HDR-look dinonaktifkan.", Toast.LENGTH_SHORT).show()
        }
        row.addView(flashButton, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(hdrButton, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button("✨ HD AI OFF") {
            aiHdEnabled = !aiHdEnabled
            Toast.makeText(this, if (aiHdEnabled) "HD AI aktif: foto akan diproses lokal untuk peningkatan ketajaman ringan." else "HD AI dinonaktifkan.", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(row)
        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        bottom.addView(button("Balik Kamera") {
            backCamera = !backCamera
            startCamera()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(button("●  FOTO HD") { takePhoto() }, LinearLayout.LayoutParams(0, -2, 1.25f))
        controls.addView(bottom)
        root.addView(controls, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setJpegQuality(100)
                .build()
            val selector = if (backCamera) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
            try {
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, selector, preview, imageCapture)
                imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
                val maxZoom = camera?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 1f
                camera?.cameraControl?.setZoomRatio(zoom.coerceAtMost(maxZoom))
            } catch (e: Exception) {
                Toast.makeText(this, "Kamera tidak dapat dimulai: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // Local lightweight enhancement, not a generative AI model. Keeps original photo unchanged.
    private fun enhancePhotoLocally(sourceUri: Uri): Boolean {
        return try {
            val input = contentResolver.openInputStream(sourceUri) ?: return false
            val original = input.use { BitmapFactory.decodeStream(it) } ?: return false
            // Keep memory use reasonable on lower-RAM phones; upscale 1.25x, capped at 12 MP.
            val targetScale = minOf(1.25f, kotlin.math.sqrt(12_000_000.0 / (original.width.toDouble() * original.height)).toFloat())
            val outW = (original.width * targetScale).toInt().coerceAtLeast(1)
            val outH = (original.height * targetScale).toInt().coerceAtLeast(1)
            val enlarged = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(enlarged)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
            canvas.drawBitmap(original, null, Rect(0, 0, outW, outH), paint)

            // Mild unsharp-mask-like edge enhancement using a small, local convolution.
            // Applied at reduced resolution to avoid excessive memory on entry-level devices.
            val maxSide = 1600
            val workScale = minOf(1f, maxSide.toFloat() / maxOf(enlarged.width, enlarged.height))
            val workW = (enlarged.width * workScale).toInt().coerceAtLeast(1)
            val workH = (enlarged.height * workScale).toInt().coerceAtLeast(1)
            val work = if (workScale < 1f) Bitmap.createScaledBitmap(enlarged, workW, workH, true) else enlarged
            val pixels = IntArray(workW * workH)
            work.getPixels(pixels, 0, workW, 0, 0, workW, workH)
            val result = IntArray(pixels.size)
            for (y in 0 until workH) {
                for (x in 0 until workW) {
                    val i = y * workW + x
                    val c = pixels[i]
                    if (x == 0 || y == 0 || x == workW - 1 || y == workH - 1) {
                        result[i] = c
                    } else {
                        val r = (Color.red(c) * 5 - Color.red(pixels[i-1]) - Color.red(pixels[i+1]) - Color.red(pixels[i-workW]) - Color.red(pixels[i+workW])).coerceIn(0,255)
                        val g = (Color.green(c) * 5 - Color.green(pixels[i-1]) - Color.green(pixels[i+1]) - Color.green(pixels[i-workW]) - Color.green(pixels[i+workW])).coerceIn(0,255)
                        val b = (Color.blue(c) * 5 - Color.blue(pixels[i-1]) - Color.blue(pixels[i+1]) - Color.blue(pixels[i-workW]) - Color.blue(pixels[i+workW])).coerceIn(0,255)
                        result[i] = Color.argb(Color.alpha(c), r, g, b)
                    }
                }
            }
            val sharpened = Bitmap.createBitmap(workW, workH, Bitmap.Config.ARGB_8888)
            sharpened.setPixels(result, 0, workW, 0, 0, workW, workH)
            val finalBitmap = if (work !== enlarged) Bitmap.createScaledBitmap(sharpened, outW, outH, true) else sharpened

            val name = "SuperHD_AI_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())}.jpg"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SuperHD Camera")
            }
            val outUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            val output = contentResolver.openOutputStream(outUri) ?: return false
            val saved = output.use { finalBitmap.compress(Bitmap.CompressFormat.JPEG, 100, it) }
            if (original !== finalBitmap) original.recycle()
            if (enlarged !== finalBitmap) enlarged.recycle()
            if (work !== enlarged && work !== finalBitmap) work.recycle()
            if (sharpened !== finalBitmap) sharpened.recycle()
            finalBitmap.recycle()
            saved
        } catch (_: Exception) {
            false
        }
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val name = "SuperHD_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SuperHD Camera")
        }
        val options = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                val uri = output.savedUri
                if (aiHdEnabled && uri != null) {
                    Toast.makeText(this@MainActivity, "Foto tersimpan. Memproses HD AI lokal…", Toast.LENGTH_SHORT).show()
                    Thread {
                        val ok = enhancePhotoLocally(uri)
                        runOnUiThread {
                            Toast.makeText(this@MainActivity,
                                if (ok) "Versi HD tersimpan sebagai foto baru di Pictures/SuperHD Camera."
                                else "Foto asli aman tersimpan, tetapi pemrosesan HD gagal.", Toast.LENGTH_LONG).show()
                        }
                    }.start()
                } else {
                    Toast.makeText(this@MainActivity, "Foto tersimpan di Pictures/SuperHD Camera • JPEG kualitas maksimum", Toast.LENGTH_LONG).show()
                }
            }
            override fun onError(exception: ImageCaptureException) {
                Toast.makeText(this@MainActivity, "Gagal mengambil foto: ${exception.message}", Toast.LENGTH_LONG).show()
            }
        })
    }
}
