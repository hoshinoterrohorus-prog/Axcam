# SuperHD Camera

Proyek Android Studio sederhana untuk kamera dengan:
- Pratinjau kamera langsung
- Foto JPEG kualitas maksimum yang didukung kamera (quality 100)
- Zoom digital yang dibatasi kemampuan kamera
- Flash dan tukar kamera depan/belakang
- Simpan otomatis ke `Pictures/SuperHD Camera`

## Cara build APK
1. Ekstrak ZIP.
2. Buka folder `SuperHD_Camera_Project` di Android Studio.
3. Izinkan Gradle mengunduh dependensi saat diminta.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan kualitas
Aplikasi ini memakai CameraX dan meminta mode tangkapan yang mengutamakan kualitas serta JPEG quality 100. Hasil tetap dibatasi sensor, lensa, ISP, dan dukungan kamera perangkat. Tombol **HDR LOOK** hanya label/demo UI; ini bukan HDR komputasional Google Camera dan tidak bisa menambahkan kemampuan sensor yang tidak tersedia. Versi ini belum merekam video atau memakai pemrosesan multi-frame/night sight.

## Mode HD AI (prototipe lokal)
- Aktifkan tombol **HD AI OFF** untuk menyalakannya.
- Setelah mengambil foto, aplikasi menyimpan foto asli lalu membuat file versi `SuperHD_AI_...jpg` sebagai salinan hasil pemrosesan lokal.
- Prototipe ini melakukan upscale ringan dan penajaman lokal, tanpa internet atau layanan cloud. Ini **belum AI generatif sungguhan** dan tidak dapat memulihkan detail yang tidak tertangkap sensor; pembesaran bisa membuat hasil terlihat lebih tajam tetapi bukan detail asli.
